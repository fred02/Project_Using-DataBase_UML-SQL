/****
** Suppresion des tables
***/

DROP TABLE SoumissionParticipant;
DROP TABLE Evaluation;

DROP TABLE MotsCles;

DROP TABLE Soumission;

DROP TABLE CompteUtilisateur;

DROP TABLE Participant;

DROP TABLE Theme;

DROP TABLE Conference;
